package main

import (
	"chainmaker/pb/protogo"
	"chainmaker/shim"
	"log"
	"strconv"
)

type FactContract struct {
}

// 存证对象
type Fact struct {
	FileHash string `json:"file_hash"`
	FileName string `json:"file_name"`
	Time     int32  `json:"time"`
}

// 新建存证对象
func NewFact(FileHash string, FileName string, time int32) *Fact {
	fact := &Fact{
		FileHash: FileHash,
		FileName: FileName,
		Time:     time,
	}
	return fact

}

func (f *FactContract) InitContract(stub shim.CMStubInterface) protogo.Response {

	return shim.Success([]byte("Init Success"))

}

func (f *FactContract) InvokeContract(stub shim.CMStubInterface) protogo.Response {

	// 获取参数
	method := string(stub.GetArgs()["method"])

	switch method {
	case "GetCreatorOrgId":
		return f.GetCreatOrgId(stub)
	case "GetCreatorRole":
		return f.GetCreatRole(stub)
	case "GetCreatpk":
		return f.GetCreatPk(stub)
	case "GetSendorgId":
		return f.GetSendorgId(stub)
	case "GetSenderrole":
		return f.GetSenderrole(stub)

	case "GetSenderPk":
		return f.GetSenderPk(stub)
	case "GetBlockHeight":
		return f.GetBlockHeight(stub)
	case "GetTxId":
		return f.GetTxId(stub)
	case "GetTxTimeStamp":
		return f.GetTxTimeStamp(stub)
		// 	case "NewIterator":
		// 		return f.NewIterator(stub)
		// 	case "NewIteratorWithField":
		// 		return f.NewIteratorWithField(stub)
		// 	case "NewIteratorPrefixWithKeyField":
		// 		return f.NewIteratorPrefixWithKeyField(stub)
		// 	case "NewIteratorPrefixWithKey":
		// 		return f.NewIteratorPrefixWithKey(stub)
		// 	case "NewHistoryKvIterForKey":
		// 		return f.NewHistoryKvIterForKey(stub)
	default:
		return shim.Error("invalid method")
	}

}

// func (f *FactContract) sana(stub shim.CMStubInterface) protogo.Response{
// 	pass
// }

func (f *FactContract) GetCreatOrgId(stub shim.CMStubInterface) protogo.Response {

	result, err := stub.GetCreatorOrgId()
	if err != nil {
		return shim.Error(err.Error())
	}

	return shim.Success([]byte(result))
}

func (f *FactContract) GetCreatRole(stub shim.CMStubInterface) protogo.Response {
	result, err := stub.GetCreatorRole()
	if err != nil {
		return shim.Error(err.Error())
	}

	return shim.Success([]byte(result))
}

func (f *FactContract) GetCreatPk(stub shim.CMStubInterface) protogo.Response {
	result, err := stub.GetCreatorPk()
	if err != nil {
		return shim.Error(err.Error())
	}

	return shim.Success([]byte(result))
}

func (f *FactContract) GetSendorgId(stub shim.CMStubInterface) protogo.Response {
	result, err := stub.GetSenderOrgId()
	if err != nil {
		return shim.Error(err.Error())
	}

	return shim.Success([]byte(result))
}

func (f *FactContract) GetSenderrole(stub shim.CMStubInterface) protogo.Response {
	result, err := stub.GetSenderRole()
	if err != nil {
		return shim.Error(err.Error())
	}

	return shim.Success([]byte(result))
}

func (f *FactContract) GetSenderPk(stub shim.CMStubInterface) protogo.Response {
	result, err := stub.GetSenderPk()
	if err != nil {
		return shim.Error(err.Error())
	}

	return shim.Success([]byte(result))
}

func (f *FactContract) GetBlockHeight(stub shim.CMStubInterface) protogo.Response {
	result, err := stub.GetBlockHeight()
	if err != nil {
		return shim.Error(err.Error())
	}
	hight := strconv.Itoa(result)
	return shim.Success([]byte(hight))
}

func (f *FactContract) GetTxId(stub shim.CMStubInterface) protogo.Response {
	result, err := stub.GetTxId()
	if err != nil {
		return shim.Error(err.Error())
	}
	return shim.Success([]byte(result))
}

func (f *FactContract) GetTxTimeStamp(stub shim.CMStubInterface) protogo.Response {
	result, err := stub.GetTxTimeStamp()
	if err != nil {
		return shim.Error(err.Error())
	}
	return shim.Success([]byte(result))
}

// func (f *FactContract) NewIterator(stub shim.CMStubInterface) protogo.Response {
// 	params := stub.GetArgs()
// 	// 获取参数
// 	startKey := string(params["startKey"])
// 	limitKey := string(params["limitKey"])
// 	result, err := stub.NewIterator(startKey, limitKey)
// 	if err != nil {
// 		return shim.Error(err.Error())
// 	}
// 	return shim.Success([]byte(result))
// }

// func (f *FactContract) NewIteratorWithField(stub shim.CMStubInterface) protogo.Response {
// 	result, err := stub.NewIteratorWithField()
// 	if err != nil {
// 		return shim.Error(err.Error())
// 	}
// 	return shim.Success([]byte(result))
// }

// func (f *FactContract) NewIteratorPrefixWithKeyField(stub shim.CMStubInterface) protogo.Response {
// 	result, err := stub.NewIteratorPrefixWithKeyField()
// 	if err != nil {
// 		return shim.Error(err.Error())
// 	}
// 	return shim.Success([]byte(result))
// }

// func (f *FactContract) NewIteratorPrefixWithKey(stub shim.CMStubInterface) protogo.Response {
// 	result, err := stub.NewIteratorPrefixWithKey()
// 	if err != nil {
// 		return shim.Error(err.Error())
// 	}
// 	return shim.Success([]byte(result))
// }

// func (f *FactContract) NewHistoryKvIterForKey(stub shim.CMStubInterface) protogo.Response {
// 	result, err := stub.NewHistoryKvIterForKey()
// 	if err != nil {
// 		return shim.Error(err.Error())
// 	}
// 	return shim.Success([]byte(result))
// }

func main() {

	err := shim.Start(new(FactContract))
	if err != nil {
		log.Fatal(err)
	}
}
